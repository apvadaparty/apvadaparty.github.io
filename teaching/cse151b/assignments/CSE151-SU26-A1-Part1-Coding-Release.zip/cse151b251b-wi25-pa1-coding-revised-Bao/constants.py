configYamlPath = "./configs/"  
saveLocation = "./plots/"
modelLocation = "./models"