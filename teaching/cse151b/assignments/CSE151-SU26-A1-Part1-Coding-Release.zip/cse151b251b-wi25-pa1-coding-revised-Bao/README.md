# PA1-Starter
1. main.py is the driver function to run different experiments. You can run it with: `python main.py --experiment <experiment_name>`.
2. the first time you run main.py, it will automatically download the data to the 'data' directory.
3. config files need to be in the 'config' directory.
5. You are free to create new functions, change existing function signatures, add/remove member variables/functions in the provided classes but you must maintain the overall given structure of the code. You must use the classes provided in neuralnet.py to create your model (although you can add or remove variables/functions in these classes or change the function signatures).
6. Sections marked as TODO are to be completed by you.
