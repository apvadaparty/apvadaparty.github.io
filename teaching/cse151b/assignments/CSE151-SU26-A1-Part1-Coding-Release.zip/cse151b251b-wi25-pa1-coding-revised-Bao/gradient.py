import numpy as np
from neuralnet import Neuralnetwork

def check_grad(model, x_train, y_train, epsilon=1e-2):

    """
    TODO
    Checks if gradients computed numerically are within O(epsilon**2)

    Args:
        model: The neural network model to check gradients for.
        x_train: Small subset of the original train dataset.
        y_train: Corresponding target labels of x_train.
        epsilon: Small constant for numerical approximation.

    Prints gradient difference of values calculated via numerical approximation and backprop implementation.
    """
    print(f"Checking gradient using epsilon {epsilon}")
    # When printing out results for gradient checking, please use this format for each weight checked 
    # layer_idx -> which layer is being checked (index 0 is input to hidden, index 1 is hidden to output)
    # i, j -> which weight in the layer is being checked
    # numerical_grad -> gradient calculated with +- epsilon
    # analytical_grad -> gradient from backpropogation 
    # diff -> difference between numerical grad and analytical grad 
    # within tolerance -> True or False 
    print(f"  Layer {layer_idx} w[{i},{j}]: numerical={numerical_grad:.6f}, analytical={analytical_grad:.6f}, diff={diff:.2e}, within tolerance = {tolerance}") 
    raise NotImplementedError("check_grad not implemented in gradient.py")



def checkGradient(x_train, y_train, config):
    
    raise NotImplementedError("checkGradient not implemented in gradient.py")
