import gradient
from constants import *
from train import *
from gradient import *
import argparse
import util 
import os
import torch

# TODO
def main(args):

    # Read the required config
    # Create different config files for different experiments
    configFile = None  # Will contain the name of the config file to be loaded
    if (args.experiment == 'test_softmax'):  # Rubric #4: Softmax Regression
        configFile = "config_4.yaml"
    elif (args.experiment == 'test_gradients'):  # Rubric #5: Numerical Approximation of Gradients
        configFile = "config_5.yaml"
    elif (args.experiment == 'test_momentum'):  # Rubric #6: Momentum Experiments
        configFile = "config_6.yaml"
    elif (args.experiment == 'test_regularization'):  # Rubric #7: Regularization Experiments
        configFile = "config_7.yaml"  # Create a config file and change None to the config file name
    elif (args.experiment == 'test_activation'):  # Rubric #8: Activation Experiments
        configFile = "config_8.yaml"  # Create a config file and change None to the config file name


    # Load the data
    datasetDir = args.data_dir
    x_train, y_train, x_valid, y_valid, x_test, y_test = util.load_data(path=datasetDir)
    # Load the configuration from the corresponding yaml file. Specify the file path and name
    config = util.load_config(configYamlPath + configFile)

    # Make sure to save/load model to/from ./models for autograding purposes 
    """
    example: 
    modelsLocation = "./models/"
    model_path = os.path.join(modelsLocation, f"trained_{args.experiment}_model.pth")
    if not os.path.exists(model_path): #train model if it does not exist
        # Create and train the model
        model = Neuralnetwork(config)
        model = train(
            model, x_train, y_train, x_valid, y_valid, config
        )
        # save trained model
        if not os.path.exists(modelsLocation):
            os.makedirs(modelsLocation)
        torch.save(model.state_dict(), model_path)

    else: #grab model if it does exist
        # Create the model architecture
        model = Neuralnetwork(config)
    
        # Load the weights
        model.load_state_dict(torch.load(model_path, weights_only = False))
    """

    # When printing out accuracy results - please use this format for autograding purposes
    print(f"Final test accuracy: {accuracy}, Test loss: {loss}") 

if __name__ == "__main__":

    #Parse the input arguments
    parser = argparse.ArgumentParser()
    parser.add_argument('--experiment', type=str, default='test_momentum', help='Specify the experiment that you want to run')
    parser.add_argument('--data_dir', type=str, default='./data', help= 'Specify the directory that your FashionMNIST data is located') 
    args = parser.parse_args()
    main(args)