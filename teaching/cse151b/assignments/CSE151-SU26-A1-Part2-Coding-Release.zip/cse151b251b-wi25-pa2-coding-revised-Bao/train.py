from basic_fcn import *
import time
from torch.utils.data import DataLoader
import torch
import gc
import voc
import torchvision.transforms as standard_transforms
import util
import numpy as np
import multiprocessing
import argparse
import os

num_workers = multiprocessing.cpu_count()

class MaskToTensor(object):
    def __call__(self, img):
        return torch.from_numpy(np.array(img, dtype=np.int32)).long()


def init_weights(m):
    if isinstance(m, nn.Conv2d) or isinstance(m, nn.ConvTranspose2d):
        torch.nn.init.xavier_uniform_(m.weight.data)
        torch.nn.init.normal_(m.bias.data) #xavier not applicable for biases



#TODO Get class weights
def getClassWeights():
    # TODO for Q4.c || Caculate the weights for the classes
    raise NotImplementedError


# TODO
def train():
    """
    Train a deep learning model using mini-batches.

    - Perform forward propagation in each epoch.
    - Compute loss and conduct backpropagation.
    - Update model weights.
    - Evaluate model on validation set for mIoU score.
    - Implement early stopping if necessary.

    Returns:
        None.
    """

    best_iou_score = 0.0

    for epoch in range(epochs):
        ts = time.time()
        for iter, (inputs, labels) in enumerate(train_loader):
            # TODO  reset optimizer gradients


            # both inputs and labels have to reside in the same device as the model's
            inputs =  inputs.to()# TODO transfer the input to the same device as the model's
            labels =   # TODO transfer the labels to the same device as the model's

            outputs =  # TODO  Compute outputs. we will not need to transfer the output, it will be automatically in the same device as the model's!

            loss =   #TODO  calculate loss

            # TODO  backpropagate

            # TODO  update the weights


            if iter % 20 == 0:
                print("epoch{}, iter{}, loss: {}".format(epoch, iter, loss.item()))

        print("Finish epoch {}, time elapsed {}".format(epoch, time.time() - ts))

        val(epoch)
    
 #TODO
def val(epoch):
    """
    Validate the deep learning model on a validation dataset.

    - Set model to evaluation mode.
    - Disable gradient calculations.
    - Iterate over validation data loader:
        - Perform forward pass to get outputs.
        - Compute loss and accumulate it.
        - Calculate and accumulate mean Intersection over Union (IoU) scores and pixel accuracy.
    - Print average loss, IoU, and pixel accuracy for the epoch.
    - Switch model back to training mode.

    Args:
        epoch (int): The current epoch number.

    Returns:
        tuple: Mean IoU score and mean loss for this validation epoch.
    """
    fcn_model.eval() # Put in eval mode (disables batchnorm/dropout) !
    
    losses = []
    mean_iou_scores = []
    accuracy = []

    with torch.no_grad(): # we don't need to calculate the gradient in the validation/testing

        for iter, (inputs, labels) in enumerate(val_loader):




    print(f"Loss at epoch: {epoch} is {np.mean(losses)}")
    print(f"IoU at epoch: {epoch} is {np.mean(mean_iou_scores)}")
    print(f"Pixel acc at epoch: {epoch} is {np.mean(accuracy)}")

    fcn_model.train() #TURNING THE TRAIN MODE BACK ON TO ENABLE BATCHNORM/DROPOUT!!

    return np.mean(mean_iou_scores)

 #TODO
def modelTest():
    """
    Test the deep learning model using a test dataset.

    - Load the model with the best weights.
    - Set the model to evaluation mode.
    - Iterate over the test data loader:
        - Perform forward pass and compute loss.
        - Accumulate loss, IoU scores, and pixel accuracy.
    - Print average loss, IoU, and pixel accuracy for the test data.
    - Switch model back to training mode.

    Returns:
        None. Outputs average test metrics to the console.
    """

    fcn_model.eval()  # Put in eval mode (disables batchnorm/dropout) !



    with torch.no_grad():  # we don't need to calculate the gradient in the validation/testing

        for iter, (inputs, labels) in enumerate(test_loader):


    #print the final results using the following output for autograding purposes 
    print(f"Final average pixel accuracy: {final_avg_pixel_acc:.4f}, final average IoU: {final_avg_iou:.4f}")
    
    fcn_model.train()  #TURNING THE TRAIN MODE BACK ON TO ENABLE BATCHNORM/DROPOUT!!


def exportModel(inputs):    
    """
    Export the output of the model for given inputs.

    - Set the model to evaluation mode.
    - Load the desired model
    - Perform a forward pass with the model to get output.
    - Switch model back to training mode.

    Args:
        inputs: Input data to the model.

    Returns:
        Output from the model for the given inputs.
    """

    fcn_model.eval() # Put in eval mode (disables batchnorm/dropout) !
    
    desired_model_path = "Fill Path To Model"
    # TODO Then Load your model using saved_model_path
    
    inputs = inputs.to(device)
    
    output_image = fcn_model(inputs)
    
    fcn_model.train()  #TURNING THE TRAIN MODE BACK ON TO ENABLE BATCHNORM/DROPOUT!!
    
    return output_image

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--experiment', dest="experiment", type=str, help='Specify the experiment that you want to run')
    parser.add_argument('--data_dir', type=str, default='./data', help= 'Specify the directory that your VOC data is located') 
    args = parser.parse_args()

    # normalize using imagenet averages
    mean_std = ([0.485, 0.456, 0.406], [0.229, 0.224, 0.225]) 
    input_transform = standard_transforms.Compose([
            standard_transforms.ToTensor(),
            standard_transforms.Normalize(*mean_std)
        ])

    target_transform = MaskToTensor()

    train_dataset = voc.VOC('train', transform=input_transform, target_transform=target_transform, data_root=args.data_dir)
    val_dataset = voc.VOC('val', transform=input_transform, target_transform=target_transform, data_root=args.data_dir)
    test_dataset = voc.VOC('test', transform=input_transform, target_transform=target_transform, data_root=args.data_dir)

    train_loader = DataLoader(dataset=train_dataset, batch_size= 16, shuffle=True, num_workers=num_workers)
    val_loader = DataLoader(dataset=val_dataset, batch_size= 16, shuffle=False, num_workers=num_workers)
    test_loader = DataLoader(dataset=test_dataset, batch_size= 16, shuffle=False, num_workers=num_workers)

    epochs = 30

    n_class = 21

    device = # TODO determine which device to use (cuda or cpu)

    models_loc = "./models"
    model_path = f"{models_loc}/{args.experiment}.pth"
    #example model load/save code
    if args.experiment == "baseline":  
        fcn_model = FCN(n_class=n_class) #this should match the model architecture of the .pth file
        optimizer = # TODO choose an optimizer
        criterion = # TODO Choose an appropriate loss function from https://pytorch.org/docs/stable/_modules/torch/nn/modules/loss.html

        if os.path.exists(model_path): #model exists, load it
            state_dict = torch.load(model_path, map_location=device)
            fcn_model.load_state_dict(state_dict)
            fcn_model = # TODO transfer the model to the device
            modelTest()

        else: #model does not exist, train and save it 
            fcn_model.apply(init_weights) 
            fcn_model = # TODO transfer the model to the device
            val(0)  # show the accuracy before training
            train()
            modelTest()
            if not os.path.exists(models_loc):
                os.makedirs(models_loc)
            torch.save(fcn_model.state_dict(), model_path)

    # housekeeping
    gc.collect()
    torch.cuda.empty_cache()
